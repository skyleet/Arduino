The "Arduino main code.txt" is a file that is used for the "reset button" in the program. It is not necesarry, but if you want this button to work, you need to keep the text file with the .exe

All necesarry information should be inside the .exe under "info", or you can use "contact".



Download link:
http://bit.ly/LED_CUBE_CODE_GENERATOR



UPDATES:

***16.03.2015***

1. Added function to change the time of already generated code. -This has a backside, if you use it to change the time of the code, the undo button will not work to undo the generated code until you delete all of it. Not really a problem, just something to have knowledge of.
2. Added function to open the Arduino program with hyperlink.


***19.03.2015***

Changed the label names from "columns" to "planes" to make the explanation of the cube more clear. Nothing else was done so the previous version is just as good, but with different labels of the planes.