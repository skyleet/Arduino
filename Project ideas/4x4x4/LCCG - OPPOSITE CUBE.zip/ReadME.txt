The "Arduino main code.txt" is a file that is used for the "reset button" in the program. It is not necesarry, but if you want this button to work, you need to keep the text file with the .exe

All necesarry information should be inside the .exe under "info", or you can use "contact".